<?php
# variabel configurasi
$host = 'localhost';
$db = 'library';
$user = 'root';
$pass = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass); # objek pdo (php data object) yang bkal ngoneksi ke mysql
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); #  attr = saklar, errmode = mode yang ngelempar exception kalau ada error
} catch (PDOException $e) { # yang nangkap eror
    die("Koneksi gagal: " . $e->getMessage()); # program otomatis mati dan akan menampilkan pesan
}
?>