<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
?>

<link rel="stylesheet" href="../css/dashboard.css">

<div class="dashboard-wrapper">

    <!-- Sidebar kiri -->
    <div class="sidebar">
        <h3 class="sidebar-title">Menu</h3>

        <a href="books.php" class="menu-btn green">Tambah Buku</a>
        <a href="genres.php" class="menu-btn gray">Tambah Genre</a>

        <div class="menu-bottom">
            <a href="logout.php" class="menu-btn dark">Logout</a>
        </div>
    </div>

    <!-- Konten kanan -->
    <div class="content">
        <h2 class="content-title">Daftar Buku</h2>

        <!-- Di sini nanti kamu tampilkan list buku -->
        <div class="book-list">
            <?php if (empty($books)): ?>
            <p>Tidak ada buku yang ditambahkan.</p>
        <?php else: ?>
            <?php foreach ($books as $b): ?>
                <div class="book-card">
                    <h3><?= htmlspecialchars($b['judul']) ?></h3>
                    <p><?= htmlspecialchars($b['penulis']) ?></p>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
        </div>
    </div>
</div>

</div>
